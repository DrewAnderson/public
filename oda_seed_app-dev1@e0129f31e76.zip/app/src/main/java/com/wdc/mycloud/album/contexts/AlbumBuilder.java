package com.wdc.mycloud.album.contexts;

import android.content.Context;
import android.util.Log;

/**
 * Copyright 2018 Western Digital Corporation. All rights reserved.
 */

public class AlbumBuilder {
    private final String TAG = AlbumBuilder.class.getSimpleName();

    private Context androidContext;
    private String token;
    private String userId;
    private String albumName;

    public AlbumBuilder() {
    }

    public AlbumBuilder setAndroidContext(Context androidContext) {
        this.androidContext = androidContext;
        return this;
    }

    public AlbumBuilder setUserId(String userId) {
        this.userId = userId;
        return this;
    }

    public AlbumBuilder setToken(String token) {
        this.token = token;
        return this;
    }

    public AlbumBuilder setAlbumName(String albumName) {
        this.albumName = albumName;
        return this;
    }

    public Album build() {

        if (androidContext == null) {
            Log.e(TAG, "androidContext is null");
        }

        if (token == null) {
            Log.e(TAG, "token is null");
        }

        if (userId == null) {
            Log.e(TAG, "userId is null");
        }

        Album myAlbum = new Album();
        myAlbum.setToken(token);
        myAlbum.setUserId(userId);
        myAlbum.setAlbumName(albumName);
        myAlbum.startAlbumCreation();

        return myAlbum;
    }
}