package com.wdc.mycloud.album;

/**
 * Copyright 2018 Western Digital Corporation. All rights reserved.
 */

public interface Constants {
    public static final String KEY_MYCLOUD_USER = "KEY_MYCLOUD_USER";
    public static final String env = "dev";
    public static final String dev_config_url = "https://dev1-config.remotewd1.com/";
    public static final String service_auth0_url = "https://wdc-dev1.auth0.com/";
    public static final String service_device_url = "https://dev1.wdtest1.com/";
    public static final String service_share_url = "https://dev1-gateway.wdtest1.com/shares";
    public static final String CLIENT_ID = "XWO8YaX2qJiqBCZmuao80n4YUmwvWGuA";
    public static final String CLIENT_SECRET = "ZnTwkCzzKbp07ezojWxldz5D8w3CLlCjs-6n6gOfTRgQEp9bIxaFJ4R8allHFsRf";

    public static final String USERNAME = "wdc.tester106@gmail.com";
    public static final String PASSWORD = "Test12345";
    public static final String GRANT_TYPE = "http://auth0.com/oauth/grant-type/password-realm";
    public static final String SCOPE = "openid nas_read_only nas_read_write user_read device_read nas_app_management offline_access";
    public static final String REALM = "Username-Password-Authentication";
    public static final String AUDIENCE = "mycloud.com";
}
