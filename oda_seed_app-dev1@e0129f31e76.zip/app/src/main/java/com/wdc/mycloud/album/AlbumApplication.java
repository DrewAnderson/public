package com.wdc.mycloud.album;

import android.app.Application;
import android.util.Log;

import io.realm.Realm;
import io.realm.RealmConfiguration;

/**
 * Copyright 2018 Western Digital Corporation. All rights reserved.
 */

public class AlbumApplication extends Application {
    public static final String TAG = AlbumApplication.class.getSimpleName();

    public static final int APP_DB_SCHEMA = 2;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e(TAG, "AlbumApplication onCreate");
        Realm.init(this);

        RealmConfiguration config = new RealmConfiguration.Builder()
                .schemaVersion(APP_DB_SCHEMA) // Must be bumped when the schema changes
                .build();
        Realm.setDefaultConfiguration(config);

    }
}
