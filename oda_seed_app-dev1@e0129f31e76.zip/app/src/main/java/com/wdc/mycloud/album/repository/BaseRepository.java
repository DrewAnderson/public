package com.wdc.mycloud.album.repository;

import android.util.Log;

import com.wdc.mycloud.album.storage.RealmLibraryModule;

import io.realm.Realm;
import io.realm.RealmConfiguration;

import static android.content.ContentValues.TAG;

/**
 * Copyright 2018 Western Digital Corporation. All rights reserved.
 */

abstract class BaseRepository {
    protected final String DB_NAME = "album.realm";

    private String getDbName() {
        return DB_NAME;
    }

    RealmConfiguration getRealmConfigFor() {
        return new RealmConfiguration.Builder()
                .name(getDbName())
                .schemaVersion(1)
                .modules(new RealmLibraryModule())
                .build();
    }

    public void onDestroy() {
        // Remove database
        RealmConfiguration config = getRealmConfigFor();
        boolean removalResult = Realm.deleteRealm(getRealmConfigFor());
        if (removalResult) {
            Log.d(TAG, String.format("Removed DB: %s", config.getRealmFileName()));
        }
    }

}
