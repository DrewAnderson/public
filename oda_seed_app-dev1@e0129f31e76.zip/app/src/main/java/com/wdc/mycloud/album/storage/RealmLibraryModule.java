/*
 * (c) 2017 Western Digital Technologies, Inc.
 */

package com.wdc.mycloud.album.storage;

import io.realm.annotations.RealmModule;
import com.wdc.mycloud.album.model.Albums;
/**
 * Copyright 2018 Western Digital Corporation. All rights reserved.
 */

// Library must create a module and set library = true. This will prevent the default
// module from being created.
@RealmModule(library = true, classes = {Albums.class})
public class RealmLibraryModule {
}