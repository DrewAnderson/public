package com.wdc.mycloud.album.rules;

/**
 * Copyright 2018 Western Digital Corporation. All rights reserved.
 */
public class Rules {
}
