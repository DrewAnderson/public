/**
 * Copyright 2017 Western Digital Corporation. All rights reserved.
 */
package com.wdc.mycloud.album.get;

import android.content.Context;
import android.content.res.AssetManager;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import fi.iki.elonen.NanoHTTPD;

import static fi.iki.elonen.NanoHTTPD.getMimeTypeForFile;
import static fi.iki.elonen.NanoHTTPD.newFixedLengthResponse;
/**
 * Copyright 2018 Western Digital Corporation. All rights reserved.
 */

public abstract class GetDelegate {
    public static final String UID = "uid";
    public static final String MYCLOUD_ID = "mycloudId";
    private static final String TAG = "GetDelegate";

    AssetManager mAssetManager;

    public GetDelegate(Context context){
        mAssetManager = context.getAssets();
    }

    public abstract NanoHTTPD.Response getHandler(NanoHTTPD.IHTTPSession session);
    public abstract NanoHTTPD.Response postHandler(NanoHTTPD.IHTTPSession session);

    /**
     * returns the resource
     * @return
     * Can move this to nassdk
     */
    protected NanoHTTPD.Response getResourceResponse(String uri) {
        try {
            InputStream inputStream = mAssetManager.open(uri.substring(1));
            return newFixedLengthResponse(NanoHTTPD.Response.Status.OK, getMimeTypeForFile(uri),
                    inputStream, inputStream.available());
        } catch (FileNotFoundException e) {
            return newFixedLengthResponse(NanoHTTPD.Response.Status.NOT_FOUND,
                    NanoHTTPD.MIME_PLAINTEXT,
                    "ERROR: FileNotFoundException: " + e.getMessage());
        } catch (IOException e) {
            return newFixedLengthResponse(NanoHTTPD.Response.Status.INTERNAL_ERROR,
                    NanoHTTPD.MIME_PLAINTEXT,
                    "ERROR: IOException: " + e.getMessage());
        } finally {

        }
    }

}
