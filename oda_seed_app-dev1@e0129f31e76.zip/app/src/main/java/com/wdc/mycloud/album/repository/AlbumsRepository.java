package com.wdc.mycloud.album.repository;

import android.content.Context;
import android.util.Log;

import com.wdc.mycloud.album.model.Albums;

import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmResults;

/**
 * Copyright 2018 Western Digital Corporation. All rights reserved.
 */

public class AlbumsRepository extends BaseRepository {
    private final String TAG = AlbumsRepository.class.getSimpleName();

    public AlbumsRepository() {
    }

    public void saveAlbum(final Albums album) {
        if (album == null) return;
        try {
            Realm realm = Realm.getInstance(getRealmConfigFor());
            realm.executeTransaction(new Realm.Transaction() {
                @Override
                public void execute(Realm realm) {
                    realm.copyToRealmOrUpdate(album);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }

    public List<Albums> fetchAlbums(String userId) {
        List<Albums> userAlbums = null;

        try {
            Realm realm = Realm.getInstance(getRealmConfigFor());
            RealmResults<Albums> albums = realm.where(Albums.class).findAll();

            userAlbums = new ArrayList<>();
            for (Albums album : albums) {
                if (album != null && album.getUsedId().contentEquals(userId)) {
                    userAlbums.add(album);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
        return userAlbums;
    }
}

