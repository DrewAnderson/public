package com.wdc.mycloud.album;

import android.content.Context;
import android.util.Log;

import com.wdc.mycloud.album.get.GetDelegate;
import com.wdc.mycloud.album.get.GetResourceDelegate;
import com.mycloud.devicelib.MyCloudUIServer;

import fi.iki.elonen.NanoHTTPD;

/**
 * Copyright 2018 Western Digital Corporation. All rights reserved.
 */

public class SampleDeviceAppUI extends MyCloudUIServer {
    private static String TAG = SampleDeviceAppUI.class.getName();
    private Context mContext;
    private static final int COOKIE_EXPIRATION_PERIOD_DAYS = 30;
    private static final String ACCESS_TOKEN_NAME = "access_token";
    private GetDelegate mGetResourceDelegate;

    public SampleDeviceAppUI(Context context) {
        super(context);
        mContext = context;
        mGetResourceDelegate = new GetResourceDelegate(context);
    }

    @Override
    public NanoHTTPD.Response get(NanoHTTPD.IHTTPSession httpSession) {
        Log.d(TAG, "##### GET request " + httpSession.getUri());

        Response response = mGetResourceDelegate.getHandler(httpSession);
        if (httpSession.getParms() != null && httpSession.getParms().containsKey(ACCESS_TOKEN_NAME)) {
            final NanoHTTPD.CookieHandler cookieHandler = new NanoHTTPD.CookieHandler(httpSession.getHeaders());

            cookieHandler.set(ACCESS_TOKEN_NAME, httpSession.getParms().get(ACCESS_TOKEN_NAME),
                    COOKIE_EXPIRATION_PERIOD_DAYS);

            cookieHandler.unloadQueue(response);
        }
        return response;
    }

    @Override
    public Response post(NanoHTTPD.IHTTPSession httpSession) {
        try{
            Response response = mGetResourceDelegate.postHandler(httpSession);
            return response;

        }catch (Exception e) {
            Log.d(TAG, "##### POST handling exception " + e.getMessage());
            return makeResponse("<h1>Sorry, folder creation failed.</h1>");
        }
    }

    private Response makeResponse(String htmlContent) {
        return newFixedLengthResponse(new Response.IStatus() {
            @Override
            public int getRequestStatus() {
                return 200;
            }

            @Override
            public String getDescription() {
                return "OK";
            }
        }, MIME_HTML, htmlContent);
    }
}