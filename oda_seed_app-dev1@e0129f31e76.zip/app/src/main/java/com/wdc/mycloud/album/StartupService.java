package com.wdc.mycloud.album;

import android.content.Intent;
import android.util.Log;

import com.mycloud.devicelib.BaseStartupService;
import com.mycloud.devicelib.MyCloudUIServer;

/**
 * Copyright 2018 Western Digital Corporation. All rights reserved.
 */

public class StartupService extends BaseStartupService {
    private static String TAG = StartupService.class.getName();
    public static final String MYCLOUD_ID = "MyCloudId";
    /**
     * App must override this method and return the UI server instance.
     * @return
     */
    @Override
    public MyCloudUIServer createMyCloudUIServer() {
        return new SampleDeviceAppUI(getApplicationContext());
    }
    /**
     * This onStartCommand() method will be called for each user in the My Cloud Device with different mycloud user-id.
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "Album App StartupService onStartCommand.... ");

        if (intent != null) {
            if (intent.getAction() != null) {
                Log.d(TAG, "Action-->" + intent.getAction());
            }
        }
        return super.onStartCommand(intent, flags, startId);
    }


}