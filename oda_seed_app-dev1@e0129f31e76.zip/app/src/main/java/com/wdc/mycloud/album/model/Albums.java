package com.wdc.mycloud.album.model;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Copyright 2018 Western Digital Corporation. All rights reserved.
 */
public class Albums extends RealmObject {
    public static final String FIELD_ID = "userId";

    @PrimaryKey
    private String userId;

    private String name;
    private String date;
    private Integer size;

    public Albums() {}

    public String getUsedId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return this.date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Integer getSize() {
        return this.size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }
}
