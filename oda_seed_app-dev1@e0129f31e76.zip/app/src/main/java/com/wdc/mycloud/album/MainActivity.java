package com.wdc.mycloud.album;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.wdc.mycloud.album.R;

/**
 * Copyright 2018 Western Digital Corporation. All rights reserved.
 */

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = new Intent(this, StartupService.class);
        intent.setAction("START");
        MainActivity.this.startService(intent);
    }
}
