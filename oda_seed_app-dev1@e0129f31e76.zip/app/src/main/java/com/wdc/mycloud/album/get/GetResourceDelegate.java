/**
 * Copyright 2017 Western Digital Corporation. All rights reserved.
 */
package com.wdc.mycloud.album.get;

import android.content.Context;
import android.util.Log;

import com.wdc.mycloud.album.contexts.Album;
import com.wdc.mycloud.album.contexts.AlbumBuilder;
import com.mycloud.devicelib.MyCloudUIServer;
import com.wdc.mycloud.album.repository.AlbumsRepository;
import com.wdc.mycloud.album.model.Albums;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Date;
import java.util.List;

import fi.iki.elonen.NanoHTTPD;

/**
 * Copyright 2018 Western Digital Corporation. All rights reserved.
 */
public class GetResourceDelegate extends GetDelegate {
    private static final String TAG = "GetResourceDelegate";
    private static final String ACCESS_TOKEN_NAME = "access_token";
    private static final String MYCLOUD_ID = "x-wd-mycloud-id";

    private Context context;
    private String token;
    private String myCloudId;
    AlbumsRepository albumsDB;

    public GetResourceDelegate(Context context) {
        super(context);
        this.context = context;
        this.albumsDB = new AlbumsRepository();
    }

    @Override
    public NanoHTTPD.Response getHandler(NanoHTTPD.IHTTPSession session) {

        if(session.getUri() == null || session.getUri().equals("/")){
            return getResourceResponse("/index.html"); //Load default page if uri is empty
        } else if(session.getUri() == null || session.getUri().equals("/scan")) {
            this.token = session.getParms().get(ACCESS_TOKEN_NAME);
            this.myCloudId = session.getHeaders().get(MYCLOUD_ID);
            Log.d(TAG,"###### token "+ token + "myCloudId "+ myCloudId);

            String msg = "{\"status\": \""+  "OK"   + "\", \"errorMsg\": \"\"}";
            // TODO: Display a table with Albums from set userId
            return NanoHTTPD.newFixedLengthResponse(NanoHTTPD.Response.Status.OK,"application/json", msg);
        } else {
            return getResourceResponse(session.getUri()); //Load the resource
        }
    }

    /**
     * The post method to serve users post requests. Anything UI want to send for backend service should ideally use post.
     * @param session
     * @return
     */
    @Override
    public NanoHTTPD.Response postHandler(NanoHTTPD.IHTTPSession session) {
        try{
            String postBody = null;
            // This one way to load form post data.
            Integer contentLength = Integer.parseInt(session.getHeaders().get( "content-length" ));
            byte[] buf = new byte[contentLength];
            try  {
                session.getInputStream().read( buf, 0, contentLength );
                postBody = new String(buf);
            }  catch( IOException e2 ) {
                Log.d(TAG, "##### parsing post body:" + e2.getMessage());
                String msg = "{\"status\": \""+  "ERROR"   + "\", \"errorMsg\": \"folder creation failed\"}";
            }

            Log.d(TAG, "##### Post Body:" + postBody);
            String albumName = null;

            String[] keyValues = postBody.split("=");
            if (keyValues != null){
                albumName = keyValues[1];
                albumName = albumName.trim();
                Log.d(TAG, "##### Album Name:" + albumName);
            }
            Log.d(TAG, "##### creating album ########");

            String rootFolderName = MyCloudUIServer.getRootFolder(this.context, myCloudId);
            String folderName = null;
            if (rootFolderName.endsWith("/")){
                folderName = MyCloudUIServer.getRootFolder(this.context,  myCloudId) + albumName;
            } else {
                folderName = MyCloudUIServer.getRootFolder(this.context,  myCloudId) + File.separator + albumName;
            }

            // add album entry to db
            Albums model = new Albums();
            model.setName(albumName);
            String date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
            model.setDate(date);
            model.setSize(5); // TODO: need to download random number of pics
            model.setUserId(this.myCloudId);
            albumsDB.saveAlbum(model);

            // fetch Album list and update UI
            List<Albums> albums = albumsDB.fetchAlbums(this.myCloudId);
            if(!albums.isEmpty()){
                Log.d(TAG, "Albums in db");
                for(Albums album: albums){
                    Log.d(TAG,"album name " + album.getName() + " userId " + album.getUsedId());
                }
            }

            // Create new album on device
            Album album = new AlbumBuilder()
                    .setAndroidContext(this.context)
                    .setToken(this.token)
                    .setUserId(this.myCloudId)
                    .setAlbumName(folderName)
                    .build();

            String msg = "{\"status\": \""+  "OK"   + "\", \"errorMsg\": \"\"}";
            return NanoHTTPD.newFixedLengthResponse(NanoHTTPD.Response.Status.OK,"application/json", msg);
        }catch (Exception e) {
            Log.d(TAG, "##### POST handling exception " + e.getMessage());
            String msg = "{\"status\": \""+  "ERROR"   + "\", \"errorMsg\": \"album creation failed\"}";
            return NanoHTTPD.newFixedLengthResponse(NanoHTTPD.Response.Status.OK,"application/json", msg);
        }
    }

}