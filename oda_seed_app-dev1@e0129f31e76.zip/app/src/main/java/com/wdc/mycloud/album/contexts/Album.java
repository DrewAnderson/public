package com.wdc.mycloud.album.contexts;

import android.text.TextUtils;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Copyright 2018 Western Digital Corporation. All rights reserved.
 */

public class Album {

    private static String TAG = Album.class.getSimpleName();
    private String token;
    private String bearerToken;
    private String userId;
    String folderName;


    // Some sample urls to download pictures.
    static final String[] urls = new String[]{
            "http://www.fodors.com/ee/files/slideshows/3-Finland-Northern-Lights.jpg",
            "http://www.singaporeair.com/saar5/images/destination/what-to-do/syd/Sydney-skyline.jpg",
            "http://www.crystalinks.com/grandcanyon700.jpg",
            "http://www.nycgo.com/images/venues/145/statueliberty_schaer-087_2__card.jpg",
            "http://www.planetware.com/photos-large/F/eiffel-tower.jpg"
    };

    public Album() {
    }

    public void setToken(String token) {
        this.token = token;
        this.bearerToken = "Bearer " + token;
    }

    public void setAlbumName(String albumName) {
        this.folderName = albumName;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void startAlbumCreation() {
        Thread serviceThread = new Thread(new Runnable() {
            @Override
            public void run() {

                File folder = createAlbum();
                for (String url : urls
                        ) {
                    downloadImage(url, folder);
                }
            }
        });
        serviceThread.start();
    }

    /**
     * Util function to create folder
     * @return
     */
    private File createAlbum(){
        File newFolder = null;
        try {
            newFolder = new File(folderName);
            if (!newFolder.exists()) {
                newFolder.mkdir();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return newFolder;
    }

    /**
     * Util function to download the image from url
     * @param imgUrl
     * @param folder
     */
    private void downloadImage(String imgUrl, File folder) {
        Log.d(TAG, "Download Task: " + imgUrl + " : " + folderName);
        try {
            URL url = new URL(imgUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000 /* milliseconds */);
            conn.setConnectTimeout(15000 /* milliseconds */);
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            // Starts the query
            conn.connect();
            int response = conn.getResponseCode();
            Log.d(TAG, "Download response code is: " + response);
            File imageFile = getWritableFile(folder, getFileName(imgUrl));
            InputStream is = conn.getInputStream();
            Log.d(TAG, "File is: " + imageFile.getAbsolutePath());
            writeContentToFile(imageFile, is);
            Log.d(TAG, "File wrote: " + getFileName(imgUrl) + " : " + folderName);
        } catch (Exception e) {
            Log.d(TAG, "Exception download Task: " + e.getMessage());
        }
    }

    /**
     * Util function to create a file
     * @param folder
     * @param fileName
     * @return
     */
    private File getWritableFile(File folder, String fileName) {
        try {
            File imageFile = new File(folder.getAbsolutePath(), fileName);
            Log.d(TAG, "File is: " + imageFile.getAbsolutePath());
            if (!imageFile.exists()) {
                imageFile.createNewFile();
            }
            return imageFile;
        } catch (Exception e) {
            Log.d(TAG, "Exception getDownloadedFileStorage : " + e.getMessage());
            throw new IllegalArgumentException("something is going wrong");
        }
    }

    /**
     * Util function to write content to file.
     * @param destFile
     * @param is
     */
    private void writeContentToFile(File destFile, InputStream is) {
        try {
            FileOutputStream fos = new FileOutputStream(destFile);

            int read = 0;
            byte[] buffer = new byte[32768];
            while ((read = is.read(buffer)) > 0) {
                fos.write(buffer, 0, read);
            }
            fos.flush();
            fos.close();
        } catch (Exception e) {
            Log.d(TAG, "Exception writeContentToFile : " + e.getMessage());
        }
    }

    /**
     * Util function to remove numbers from the file name.
     * @param url
     * @return
     */
    private String getFileName(String url) {
        if (!TextUtils.isEmpty(url)) {
            if (url.lastIndexOf('/') > 0) {
                String name = url.substring(url.lastIndexOf('/') + 1);
                name = name.replaceAll("\\d", "");
                return name;
            }
        }
        throw new IllegalArgumentException("please provide valid url");
    }
}