import falcon
import gevent.pool
import logger
import logging
import os
import re
import requests
import rfc6266
import tempfile
import ujson
import uuid
from shimconfig import config

log = logger.get_logger()

def assert_space_available(file_size, access_token, device_url=None):
	"""Asserts that the device has enough room for a specified filesize

	Args:
		file_size: Minimum amount of space (bytes) that needs to be available for assertion to pass
		access_token: OAuth2 access token corresponding to a   user/device
		device_url: Optional cached device endpoint associated with the user/device. A lookup will be done if not provided
	Returns:
		True if device used storage exceeds capacity
	"""
	if (device_url is None):
		device_url = get_device_url(access_token)
	headers = {'Authorization': access_token}
	resp = send_request('GET', device_url + '/sdk/v1/device', headers=headers)
	if (resp.status_code == 401):
		raise ShimHTTPError(falcon.HTTP_401, 'Invalid access token')
	if (resp.status_code != 200):
		try:
			message = resp.json()['message']
		except:
			message = None
		raise ShimHTTPError(falcon.HTTP_500, 'Failed to get device capacity usage', logging.ERROR, 'is_device_full(): MyCloud device server returned ' + str(resp.status_code) + ((': ' + message) if message is not None else ''))
	try:
		body = resp.json()
		capacity = int(body['storage']['capacity'])
		used = int(body['storage']['used'])
	except:
		raise ShimHTTPError(falcon.HTTP_500, 'Failed to parse device capacity usage', logging.ERROR, 'is_device_full(): Unexpected data returned')
	try:
		file_size = int(file_size)
	except:
		log.warning("Invalid file_size (" + str(file_size) + ") passed into assert_space_available(), skipping capacity check")
	else:
		if ((used + file_size) > capacity):
			raise ShimHTTPError(falcon.HTTP_400, 'Not enough space on device for file', add_skip_status=True)

def create_remote_file(name, access_token, device_url=None, resumable=False, parent_id='root', is_directory=False, resolve_name_conflict=True):
	"""Create a remote file or directory on a   device.

	This only creates the file, but does not populate the content.

	Args:
		name: File or directory name to create
		access_token: OAuth2 access token corresponding to a   user/device
		device_url: Optional cached device endpoint associated with the user/device. A lookup will be done if not provided.
		resumable: Whether or not to make the created file resumable
		parent_id: The ID (or 'root') of the parent directory to create the file/directory in
		is_directory: Whether or not the created item is a file or directory
		resolve_name_conflict: Whether or not to append a number if file already exists (otherwise server will return a 409)
	Returns:
		The created file/directory endpoint URI
	"""
	if (device_url is None):
		device_url = get_device_url(access_token)
	boundary='mycloudifttt'
	headers = {'Authorization': access_token, 'Content-Type': 'multipart/related;boundary=' + boundary}
	body = {'name': name, 'parentID': parent_id}
	if (is_directory):
		body['mimeType'] = 'application/x.wd.dir'
	data = '\r\n--' + boundary + '\r\n\r\n' + ujson.dumps(body) + '\r\n--' + boundary + '--'
	resp = send_request('POST', device_url + '/sdk/v2/files' + ('/resumable' if resumable else '') + '?resolveNameConflict=' + ('true' if resolve_name_conflict else 'false'), headers=headers, data=data)
	if (resp.status_code == 400):
		try:
			message = resp.json()['message']
		except:
			message = 'Bad request'
		raise ShimHTTPError(falcon.HTTP_400, message, logging.ERROR, add_skip_status=True)
	if (resp.status_code == 401):
		raise ShimHTTPError(falcon.HTTP_401, 'Invalid access token')
	if (resp.status_code == 409):
		raise ShimHTTPError(falcon.HTTP_400, 'File already exists', add_skip_status=True)
	if (resp.status_code != 201):	#TODO refine this
		try:
			message = resp.json()['message']
		except:
			message = None
		raise ShimHTTPError(falcon.HTTP_500, 'Failed to create remote file on device', logging.ERROR, 'create_remote_file(): MyCloud device server returned ' + str(resp.status_code) + ((': ' + message) if message is not None else ''))
	try:
		log.debug('Created ' + ('dir \'' if is_directory else 'file \'') + os.path.basename(resp.headers['location'] + '\''))
		return device_url + resp.headers['location']
	except KeyError:
		raise ShimHTTPError(falcon.HTTP_500, 'Could not get URL to newly created file', logging.ERROR, 'create_remote_file(): MyCloud device server did not include location header in response')

def get_device_url(access_token):
	"""Gets the device endpoint associated with an access token

	This will make two requests to the MyCloud API: firstly, to look up the user ID associated with the access token, and secondly, to get the actual device URL.
	Liberal use of this function may result in the MyCloud API returning HTTP 429, so try to cache the device URL when possible.

	Args:
		access_token: OAuth2 access token corresponding to a   user/device
	Returns:
		The device URL
	"""
	user_info = get_user_info(access_token)
	headers = {'Authorization': access_token}
	# TODO: sanitize userID before passing into URL
	resp = send_request('GET', config['mycloud.device_host'] + '/device/v1/user/' + user_info['sub'], headers=headers)
	if (resp.status_code == 200):
		try:
			# Only get the first device; on   there's only one device anyways
			return resp.json()['data'][0]['network']['proxyURL']
		except:
			# TODO: This assumes user error because there was no device found. If this is a parsing error, then the JSON was unexpected and we should deal with that
			raise ShimHTTPError(falcon.HTTP_400, 'Could not find a device associated with user', logging.WARNING, 'Could not parse a device proxyURL for user ' + user_info['sub'], add_skip_status=True)
	elif (resp.status_code == 401):
		raise ShimHTTPError(falcon.HTTP_401, 'Invalid access token')
	else:
		try:
			message = resp.json()['error']['message']
		except:
			message = None
		raise shim.HTTPError(falcon.HTTP_500, 'Could not get device info', logging.ERROR, 'get_device_url(): MyCloud device server returned ' + resp.status_code + ((': ' + message) if message is not None else ''))

def get_remote_directory_id(name, access_token, device_url=None, parent_id='root'):
	"""Retrieve the ID for a directory (creating the directory if necessary)

	Args:
		name: Name of directory
		access_token: OAuth2 access token corresponding to a   user/device
		device_url: Optional cached device endpoint associated with the user/device. A lookup will be done if not provided
		parent_id: The ID of the parent directory to search in, or 'root'
	Returns:
		The ID of the requested directory
	"""
	if (device_url is None):
		device_url = get_device_url(access_token)
	# Special root case
	if (parent_id == 'root' and name == '.'):
		return 'root'
	headers = {'Authorization': access_token}
	resp = send_request('GET', device_url + '/sdk/v2/filesSearch/parentAndName?parentID=' + parent_id + '&name=' + name + '&fields=id,mimeType,childCount&pretty=false', headers=headers)
	if (resp.status_code == 401):
		raise ShimHTTPError(falcon.HTTP_401, 'Invalid access token')
	if (resp.status_code == 404):
		# Folder DNE, create it
		return os.path.basename(create_remote_file(name, access_token, device_url=device_url, resumable=False, parent_id=parent_id, is_directory=True))
	if (resp.status_code != 200):
		try:
			message = resp.json()['message']
		except:
			message = None
		raise ShimHTTPError(falcon.HTTP_500, 'Failed to get remote directory from device', logging.ERROR, 'get_remote_directory_id(): MyCloud device server returned ' + str(resp.status_code) + ((': ' + message) if message is not None else ''))
	try:
		body = resp.json()
		dir_id = body['id']
		mime = body['mimeType']
	except:
		raise ShimHTTPError(falcon.HTTP_500, 'Unexpected data when retrieving directory ID', logging.ERROR, 'get_remote_directory_id(): Unexpected data returned')
	if (mime == 'application/x.wd.dir'):
		return dir_id
	raise ShimHTTPError(falcon.HTTP_400, 'A non-directory file already exists in requested path', add_skip_status=True)

def get_test_access_token():
	"""Gets an access token using a long-lived refresh token from the config file

	This is used only for IFTTT endpoint tests

	Returns:
		Access token
	"""
	try:
		get_user_info("Bearer " + config['test.access_token'])
	except:
		try:
			data = {'client_id': config['mycloud.client_id'], 'client_secret': config['mycloud.client_secret'], 'grant_type': 'refresh_token', 'refresh_token': config['test.refresh_token']}
			resp = send_request('POST', config['mycloud.user_host'] + '/oauth/token', data=data)
			if (resp.status_code == 200):
				log.info('Successfully refreshed test access token')
			config['test.access_token'] = resp.json()['access_token']
		except:
			raise ShimHTTPError(falcon.HTTP_500, 'Could not refresh test access token', logging.ERROR, 'Could not refresh test access token, OAuth2 refresh token might be invalid')
	return config['test.access_token']

def get_user_info(access_token):
	"""Gets user profile information from the auth endpoint

	Args:
		access_token: OAuth2 access token corresponding to a   user/device
	Returns:
		A JSON object with user information. Guaranteed keys include 'sub' (ID) and 'name'
	"""
	headers = {'Authorization': access_token}
	resp = send_request('GET', config['mycloud.user_host'] + '/userinfo', headers=headers)
	if (resp.status_code == 200):
		try:
			user_info = resp.json()
			if ('sub' in user_info and 'email' in user_info):	# Make sure the json format is what we expect
				return user_info
			raise ShimHTTPError(falcon.HTTP_500, 'Missing data when retrieving user info', logging.ERROR, 'MyCloud userinfo body did not contain \'sub\' or \'email\' fields')
		except ValueError:
			raise ShimHTTPError(falcon.HTTP_500, 'Unexpected data when retrieving user info', logging.ERROR)
	elif (resp.status_code == 401):
		raise ShimHTTPError(falcon.HTTP_401, 'Invalid access token')
	else:
		raise ShimHTTPError(falcon.HTTP_503, 'Error when retrieving user info', logging.WARNING, 'get_user_info(): MyCloud user server returned ' + str(resp.status_code))

def update_cloud_hosts():
	"""Attempts to overwrite cloud service URLs specified in the config with values obtained from the   config endpoint"""
	config_endpoint = config['mycloud.config_host'] + '/config/v1/config'
	try:
		resp = send_request('GET', config_endpoint)
		services = resp.json()['data']['componentMap']['cloud.service.urls']
		config['mycloud.user_host'] = services['service.auth0.url']
		config['mycloud.device_host'] = services['service.device.url']
		config['mycloud.dashboard_url'] = services['webclient.mycloud.url']
	except:
		log.warning('Could not update cloud service URLs from ' + config_endpoint)
		pass
