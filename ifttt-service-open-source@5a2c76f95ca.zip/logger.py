import logging
import os
import sys
from shimconfig import config

LOGGER_NAME = 'iftttshim'

class LogFilter(logging.Filter):
	def __init__(self, level):
		self.level = level

	def filter(self, record):
		return record.levelno < self.level

def get_logger():
	"""Get the logger instance"""
	return logging.getLogger(LOGGER_NAME)

def init_logger():
	"""Attaches handlers to the logger and sets the loglevel based on what was specified in the config"""
	logger = get_logger()
	if (not len(logger.handlers)):
		# Create logging directory if needed
		try:
			os.makedirs(os.path.dirname(config['logging.logfile']))
		except:
			pass
		loglevel = config['logging.level']
		logfile = config['logging.logfile']
		datefmt = config['logging.date_format'] or None
		formatter = logging.Formatter(fmt="%(asctime)s - %(levelname)s - %(message)s", datefmt=datefmt)
		stderr_threshold = logging.WARNING
		stdout_handler = logging.StreamHandler(sys.stdout)
		stderr_handler = logging.StreamHandler(sys.stderr)
		stdout_handler.addFilter(LogFilter(stderr_threshold))
		stdout_handler.setLevel(loglevel)
		stderr_handler.setLevel(max(loglevel, stderr_threshold))
		stdout_handler.setFormatter(formatter)
		stderr_handler.setFormatter(formatter)
		logger.setLevel(loglevel)
		if (logfile):
			logfile_handler = logging.handlers.TimedRotatingFileHandler(filename=logfile, when='M', interval=config['logging.rotate_interval'], backupCount=config['logging.max_logs'])
			logfile_handler.setFormatter(formatter)
			logger.addHandler(logfile_handler)
		logger.addHandler(stdout_handler)
		logger.addHandler(stderr_handler)