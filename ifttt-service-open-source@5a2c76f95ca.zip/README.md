# My Cloud + IFTTT
This source demonstrates how the IFTTT service work with My Cloud Home. The app include  authentication and file management.

Check the My cloud developer portal(https://developer.mycloud.com/) to better understand my cloud home development.
## Quickstart
On an Ubuntu 16.04 installation:
```
sudo apt install python3-dev python3-pip python3-virtualenv python3-venv
cd ~
git clone <github location>
cd IFTTT
cp config.ini.sample config.ini
python3 -m venv venv
source venv/bin/activate
pip install falcon gevent gunicorn requests rfc6266 ujson
```
If you are running Python 3.4 or below, you may also need to run:
```
pip install configparser
```
`config.ini` has some sensitive values unset.
Open `~/IFTTT/config.ini` and set the appropriate values for the following:
* `general.ifttt_api_key`
* `mycloud.client_id`
* `mycloud.client_secret`
* `test.refresh_token`

Then run:
```
gunicorn --bind=0.0.0.0:80 --worker-class=gevent --workers=4 --worker-connections=1000 shim:app
```

Note that the network interface/port, workers, and threads can be tuned.
If everything worked, the shim server should be ready to bridge IFTTT to Kamino devices.

The server can be stopped with `ctrl-c`, and the venv can be exited with `deactivate`.


## Create a free account in My Cloud
Go to My Cloud Home(https://home.mycloud.com/) and click Sign Up.


## Issue Reporting
If you have found any issue or if you have a feature request, please report it at the github location. If you have any general comment on WD Cloud Home product, please use the developer portal to report it (https://developer.mycloud.com/community/report-issue).


## Author
My Cloud Home


## License
This project is licensed under <> license. See the <LICENSE> file for more info.
