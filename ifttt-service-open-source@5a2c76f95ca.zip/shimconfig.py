import configparser
import logging

"""A schema of sections and items that should exist in the config file, as well as the type conversions that should be performed on the values"""
config_schema = {
	'general': {
		'ifttt_api_key': str,
		'default_ifttt_directory': str,
		'update_cloud_hosts': bool,
		'allow_missing_content_length': bool
	},
	'mycloud': {
		'config_host': str,
		'user_host': str,
		'device_host': str,
		'dashboard_url': str,
		'client_id': str,
		'client_secret': str
	},
	'network': {
		'buflen': int,
		'http_timeout': int
	},
	'test': {
		'refresh_token': str,
		'test_samples': str
	},
	'logging': {
		'logfile': str,
		'level': str,
		'date_format': str,
		'use_error_id': bool,
		'rotate_interval': int,
		'max_logs': int
	}
}

def parse_config(config_file):
	"""Parse a config file into a 'config' object. Options under a specific section will be parsed into config['section.option']
	Basic type-checking and conversion are performed according to config_schema, so invalid values will throw an exception
	"""
	global config
	try:
		parser = configparser.ConfigParser(interpolation=None)
		if(parser.read(config_file) != [config_file]):
			raise FileNotFoundError(config_file)
		for (section, options) in config_schema.items():
			for(option, option_type) in options.items():
				if (not parser.has_section(section)):
					raise configparser.NoSectionError(section)
				if (not parser.has_option(section, option)):
					raise configparser.NoOptionError(option, section)
				if (option_type is bool):
					value = parser.getboolean(section, option)
				else:
					value = option_type(parser[section][option])
				# Special case: convert loglevel string to a numerical constant
				if (section == 'logging' and option == 'level'):
					value = parse_loglevel(value)
				config[section + '.' + option] = value
	except:
		config = {}
		raise

def parse_loglevel(level):
	level = level.lower()
	if (level == "debug"):
		return logging.DEBUG
	if (level == "info"):
		return logging.INFO
	if (level == "warning"):
		return logging.WARNING
	if (level == "error"):
		return logging.ERROR
	if (level == "critical"):
		return logging.CRITICAL
	raise configparser.ParsingError('logging.level has invalid value \'' + level + '\'')

config = {}