import gevent.monkey
gevent.monkey.patch_all()
import falcon
import logger
import logging
import os
import shimconfig
import sys
import ujson
import utils
import mycloud
from shimconfig import config

log = logger.get_logger()

class ServiceStatusResource(object):
	"""Service status endpoint"""
	@falcon.before(utils.verify_apikey_header)
	def on_get(self, req, resp):
		"""GET /ifttt/v1/status"""
		if (config['general.update_cloud_hosts']):
			mycloud.update_cloud_hosts()
		try:
			# Verify cloud service URLs are online
			utils.send_request('GET', config['mycloud.user_host'] + '/test').raise_for_status()
			utils.send_request('OPTIONS', config['mycloud.device_host'] + '/device/v1/user').raise_for_status()
			resp.status = falcon.HTTP_200
		except:
			raise utils.ShimHTTPError(falcon.HTTP_503, 'MyCloud servers offline', logging.ERROR)

class UserInfoResource(object):
	"""User info endpoint"""
	@falcon.before(utils.verify_auth_header)
	def on_get(self, req, resp):
		"""GET /ifttt/v1/user/info"""
		user_info = mycloud.get_user_info(req.auth)
		try:
			resp.body = ujson.dumps({'data': {
				'name': user_info['email'],
				'id': user_info['sub'],
				'url': config['mycloud.dashboard_url']
			}})
			resp.status = falcon.HTTP_200
		except:
			# Shouldn't happen since we raise exceptions in utils.get_user_info() but just in case
			raise utils.ShimHTTPError(falcon.HTTP_500, 'Something went wrong parsing user info', logging.ERROR)

class SaveActionResource(object):
	"""Save to MyCloud action endpoint"""
	@falcon.before(utils.verify_auth_header)
	def on_post(self, req, resp):
		"""POST /ifttt/v1/actions/save_to_mycloud"""
		# Get action fields
		try:
			body_json = ujson.loads(req.stream.read().decode('utf-8'))
			fields = body_json['actionFields']
			try:
				ifttt_source = body_json['ifttt_source']
				log.debug("Applet fired our action (ID=" + ifttt_source['id'] + ", url=" + ifttt_source['url'])
			except:
				pass
		except:
			raise utils.ShimHTTPError(falcon.HTTP_400, 'Request body was malformed', logging.WARNING)
		source_url = utils.get_value(fields, 'file_url')
		if (source_url is None):
			raise utils.ShimHTTPError(falcon.HTTP_400, 'Missing \'url\' parameter', logging.WARNING)
		filename = utils.get_value(fields, 'filename')
		subfolder = utils.get_value(fields, 'subfolder', config['general.default_ifttt_directory'])

		# Get the  associated with the token
		device_url = mycloud.get_device_url(req.auth)

		# Get the immediate parent directory for the target path we are saving to (creating directories as needed)
		stack = utils.get_directory_stack(subfolder)
		directory_id = 'root'
		while(stack):
			directory_id = mycloud.get_remote_directory_id(stack.pop(), req.auth, device_url=device_url, parent_id=directory_id)

		# Set the filename to the remote file default if filename not provided by IFTTT
		details = utils.get_external_file_details(source_url)
		if (filename is None):
			filename = details['filename']

		# Check if there's enough room for file (only if we know the target filesize)
		if(details['size'] is not None):
			mycloud.assert_space_available(details['size'], req.auth, device_url)

		# Create a blank file on the under the requested directory
		file_endpoint = mycloud.create_remote_file(filename, req.auth, device_url=device_url, resumable=True, parent_id=directory_id)

		# As per the IFTTT API team's communication, we should return 200 immediately barring any errors, and do the hard work later
		resp.status = falcon.HTTP_200
		resp.body = ujson.dumps({'data': [{'id': os.path.basename(file_endpoint), 'url': file_endpoint + '/content?access_token=' + req.auth[7:] + '&download=1'}]})

		# Add a new asynchronous transfer job
		pool.add_transfer(source_url, file_endpoint, req.auth)

class TestResource(object):
	"""Endpoint tests setup endpoint"""

	template = {
		'data': {
			'accessToken': '',
			'samples': {}
		}
	}

	def __init__(self):
		self.load_samples()

	def load_samples(self):
		try:
			with open(config['test.test_samples']) as f:
				samples_json = ujson.load(f)
				self.template['data']['samples'] = samples_json['samples']
		except FileNotFoundError:
			log.error('Could not load endpoint samples \'' + config['test.test_samples'] + '\'')
		except:
			log.error('Error parsing endpoint samples \'' + config['test.test_samples'] + '\'')

	@falcon.before(utils.verify_apikey_header)
	def on_post(self, req, resp):
		"""POST /ifttt/v1/test/setup"""
		log.info("Received an endpoint test request")
		self.template['data']['accessToken'] = utils.get_test_access_token()
		resp.body = ujson.dumps(self.template)

try:
	shimconfig.parse_config('config.ini')
except Exception as e:
	log.critical('Error parsing config: ' + str(e))
else:
	logger.init_logger()
	log.info('Started up shim worker!')
	pool = utils.TransferPool(100)
	app = falcon.API()
	app.set_error_serializer(utils.ifttt_http_error_serializer)
	app.add_route('/ifttt/v1/status', ServiceStatusResource());
	app.add_route('/ifttt/v1/user/info', UserInfoResource());
	app.add_route('/ifttt/v1/actions/save_to_mycloud', SaveActionResource());
	app.add_route('/ifttt/v1/test/setup', TestResource())
