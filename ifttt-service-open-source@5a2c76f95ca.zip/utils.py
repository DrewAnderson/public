import falcon
import gevent.pool
import logger
import logging
import os
import re
import requests
import rfc6266
import tempfile
import ujson
import uuid
from shimconfig import config

log = logger.get_logger()

class ShimHTTPError(falcon.HTTPError):
	"""A wrapper for falcon.HTTPError that will also log errors if requested

	The logging will only happen when falcon serializes the error for response; see ifttt_http_error_serializer()
	Raising this error in a falcon responder will send the approriate HTTP response. It will also generate an error ID that be used to cross-reference returned errors to IFTTT with our logs.

	Args:
		status: HTTP Status, e.g. "401 Unauthorized". For convenience use falcon constants, such as falcon.HTTP_401
		body: The description of the error to return in the response body
		loglevel: If provided, will log the HTTP error
		log_message: If provided, will be used as the logging message, otherwise body will be used. Does nothing if loglevel is not provided
		add_skip_status: Whether to append 'status=SKIP' to the returned JSON body (for IFTTT skipped actions)
		error_id: An error ID to pass through instead of generating a new one (e.g. if catching and raising a new ShimHTTPError)
	"""
	HTTP_STATUS_REGEX = re.compile("^[0-9]{3} .+$")

	def generate_error_id(self):
		"""Generate a unique error ID for cross-reference"""
		# Here we are using the last 6 bytes of UUIDv4 for convenience since avoiding collisions isn't critically important
		return str(uuid.uuid4())[-12:]

	def __init__(self, status, body=None, loglevel=None, log_message=None, add_skip_status=False, error_id=None):
		if (not self.HTTP_STATUS_REGEX.match(status)):
			log.error('ShimHTTPError was raised with a bad status \'' + status + '\', defaulting to HTTP 500')
			status = falcon.HTTP_500
		self.status_code = int(status[:3])
		try:
			self.use_error_id = config['logging.use_error_id']
		except:
			# In case we call this before config was parsed
			self.use_error_id = False
		if (self.use_error_id):
			self.error_id = self.generate_error_id() if error_id is None else error_id
		else:
			self.error_id = ''
		self.loglevel = loglevel
		self.log_message = log_message if log_message is not None else body
		self.add_skip_status = add_skip_status
		super().__init__(status, description=body)

	def __str__(self):
		ret = self.status + ': ' + self.description
		if (self.use_error_id):
			ret = ret +  ' (ref ' + self.error_id + ')'
		return ret

class TransferPool(object):
	def __init__(self, size):
		self.pool = gevent.pool.Pool(size)

	def add_transfer(self, url, remote_endpoint, access_token):
		if (self.pool.full()):
			# TODO: should we do anything besides error out?
			raise ShimHTTPError(falcon.HTTP_503, 'Server is too busy', logging.WARNING, 'Could not add new connection because worker pool is full')
		else:
			self.pool.spawn( _transfer_noncached, url, remote_endpoint, access_token)

def verify_apikey_header(req, resp, resource, params):
	"""Asserts the API key from a request header is valid"""
	received_key = req.get_header('IFTTT-Channel-Key', default=None)
	if (received_key is None):
		raise ShimHTTPError(falcon.HTTP_401, 'Missing channel key')
	if (received_key != config['general.ifttt_api_key']):
		raise ShimHTTPError(falcon.HTTP_401, 'Invalid channel key \'' + received_key + '\'')

def verify_auth_header(req, resp, resource, params):
	"""Asserts that the authentication header exists in a request"""
	if (req.auth is None):
		raise ShimHTTPError(falcon.HTTP_401, 'Missing authentication')

def get_value(obj, key, default=None):
	"""Safely get a value from an object using a key, returning a default value if value is non-existent or empty string"""
	return obj[key] if (key in obj and obj[key] != '') else default

def ifttt_http_error_serializer(req, resp, exception):
	"""A custom serializer used for Falcon to set body as requested by IFTTT when HTTP status is an error"""
	if(exception.description is not None):
		# Create the error body
		description = exception.description
		try:
			try:
				use_error_id = config['logging.use_error_id']
			except:
				# In the weird case where the serializer is called before the config was parsed
				use_error_id = False
			if (exception.loglevel is not None):
				log_message = exception.log_message
				if (use_error_id):
					description = description + ' (error reference ' + exception.error_id + ')'
					log_message = log_message + ' (ref ' + exception.error_id + ')'
				log.log(exception.loglevel, 'Returning ' + exception.status + ((': ' + log_message) if log_message is not None else ''))

		except Exception as e:
			if (type(exception) is falcon.HTTPError):
				# Allow raising of falcon.HTTPError instead of ShimHTTPError
				pass
			else:
				# We probably screwed up in the try block
				log.critical('Error in serializer: ' + str(e))
		body = {'errors': [{'message': description}]}
		try:
			if (exception.add_skip_status):
				body['errors'][0]['status'] = "SKIP"
		except:
			pass
		resp.body = ujson.dumps(body)

def  _transfer_noncached(url, remote_endpoint, access_token):
	"""Worker function which will stream a download, and upload it in chunks to a   file endpoint

	Any errors that are raised during this function will be logged and squelched, since we can't respond to IFTTT with a second HTTP status.
	Therefore, there are no guarantees that a file transfer to the   device is completely successful.

	Args:
		url: URL of file to download (http or https)
		remote_endpoint: The   file endpoint URL to upload to
		access_token: OAuth2 access token corresponding to a   user/device
	"""
	try:
		chunked_download_upload(url, remote_endpoint, access_token)
	except ShimHTTPError as e:
		# Since we've already returned 200 to IFTTT at this point, any errors that happened with upload/download aren't really handled
		log.error('Suppressed error when transferring to device: ' + str(e))

def send_request(method, url, **kwargs):
	"""Wrapper for requests.request() that will raise ShimHTTPError instead"""
	try:
		return requests.request(method, url, timeout=config['network.http_timeout'], **kwargs)
	except requests.exceptions.Timeout:
		raise ShimHTTPError(falcon.HTTP_503, 'Request timed out', logging.ERROR, 'Request timed out (method=' + method + ')')
	except requests.exceptions.ConnectionError:
		raise ShimHTTPError(falcon.HTTP_503, 'Connection failed', logging.ERROR, 'Connection failed (method=' + method + ')')
	except requests.exceptions.TooManyRedirects:
		raise ShimHTTPError(falcon.HTTP_503, 'Too many redirects', logging.ERROR, 'Too many redirects (method=' + method + ')')
	except ValueError:
		raise ShimHTTPError(falcon.HTTP_400, 'Request contained invalid URL or headers', logging.ERROR, 'Request contained invalid URL or headers (method=' + method + ')')
	except requests.exceptions.RequestException as e:
		raise ShimHTTPError(falcon.HTTP_500, 'Something was wrong with the request', logging.ERROR, 'Unknown request error (method=' + method + '): ' + e.__class__.__name__ + ': ' + str(e))

def get_directory_stack(path):
	"""Explodes a given relative path into a stack of subfolders, with the top of the stack as the leftmost part of the path

	For example, stack = get_directory_stack('my/path/here'), stack.pop() will return "my",

	Args:
		path: An arbitrary relative path. Note that /test/path/ is equivalent to test/path.
	Returns:
		The split path as a stack

	"""
	# Normalize path for OS, and strip out whitespace and leading slashes
	try:
		norm_path = os.path.normpath(path).strip().strip('/')
		stack = []
		while(True):
			stack.append(os.path.basename(norm_path))
			parent = os.path.dirname(norm_path)
			if (parent == ''):
				break
			norm_path = parent
		return stack
	except:
		raise ShimHTTPError(falcon.HTTP_400, 'Malformed directory path', logging.WARNING, 'Could not sanitize path \'' + path + '\'' , add_skip_status=True)

def get_external_file_details(url):
	"""Get filename and Content-Length through a HEAD request

	filename is calculated through the Content-Disposition header if it exists, or from the basename of the URL

	Args:
		url: URL of file (http or https)
	Returns:
		An object with keys 'filename' and 'size'. If Content-Length could not be parsed, 'size' is 0.
	"""
	try:
		resp = send_request('HEAD', url)
	except ShimHTTPError as e:
		# If we get a connection error, it's not our fault, so send a 400 instead
		raise ShimHTTPError(falcon.HTTP_400, 'Download from remote URL failed', logging.WARNING, 'HEAD remote URL failed: ' + e.description, add_skip_status=True, error_id=e.error_id)
	if (not resp.ok):
		# Workaround: retry with GET if server doesn't support HEAD
		try:
			resp = send_request('GET', url, stream=True)
		except ShimHTTPError as e:
			raise ShimHTTPError(falcon.HTTP_400, 'Download from remote URL failed', logging.WARNING, 'GET remote URL failed: ' + e.description, add_skip_status=True, error_id=e.error_id)
		finally:
			resp.close()
		if (not resp.ok):
			# Both options exhausted, give up
			raise ShimHTTPError(falcon.HTTP_400, 'Server responded with ' + str(resp.status_code) + ' when requesting download', logging.WARNING, add_skip_status=True)

	# Validate Content-Length
	try:
		content_length = int(resp.headers['content-length'])
	except ValueError:
		content_length = 0
	except KeyError:
		content_length = None if config['general.allow_missing_content_length'] else 0
	if(content_length is not None and content_length < 1):
		raise ShimHTTPError(falcon.HTTP_400, 'Requested file has invalid Content-Length header', add_skip_status=True)

	# filename_sanitized() requires an extension, so add a dummy, then strip it
	filename = rfc6266.parse_requests_response(resp).filename_sanitized('x')[:-2]
	return {'filename': filename, 'size': content_length}

def chunked_download_upload(url, remote_endpoint, access_token):
	"""Download a file, and upload it in chunks to the specified   remote file endpoint

	Args:
		url: URL of file (http or https)
		remote_endpoint: The   file endpoint URL to upload to
		access_token: OAuth2 access token corresponding to a   user/device
	"""
	try:
		remote = send_request('GET', url, stream=True)
	except ShimHTTPError as e:
		# If we get a bad server response, it's not our fault, so send a 400 instead
		raise ShimHTTPError(falcon.HTTP_400, 'Download from remote URL failed' + e.description, logging.WARNING, 'GET remote URL failed: ' + e.description, add_skip_status=True, error_id=e.error_id)

	if (not remote.ok):
		# Both options exhausted, give up
		raise ShimHTTPError(falcon.HTTP_400, 'Server responded with ' + str(resp.status_code) + ' when requesting download', logging.WARNING, add_skip_status=True)

	content_endpoint = remote_endpoint + '/resumable/content'
	basename = os.path.basename(remote_endpoint)
	etag = None
	headers = {'Authorization': access_token}
	i = 0
	try:
		log.debug('Transferring to file endpoint ' + basename + ' ...')
		for buf in remote.iter_content(chunk_size=config['network.buflen']):
			if (etag is not None):
				headers['ETag'] = etag
			resp = send_request('PUT', content_endpoint + '?offset=' + str(i), headers=headers, data=buf)
			if (resp.status_code == 204):
				etag = resp.headers['etag']
				i += config['network.buflen']
				gevent.sleep(0)
			else:
				try:
					message = resp.json()['message']
				except:
					message = None
				raise ShimHTTPError(falcon.HTTP_500, 'Error uploading file to device', logging.ERROR, 'Device server returned ' + str(resp.status_code) + ' when uploading file chunk to endpoint')
			# Mark the file upload as complete
		resp = send_request('PUT', content_endpoint + '?done=1', headers=headers)
		log.debug('Successfully transferred to file endpoint ' + basename)
	except ShimHTTPError as e:
		raise ShimHTTPError(falcon.HTTP_500, 'Error uploading file to device', logging.ERROR, 'Error uploading: ' + e.log_message, error_id=e.error_id)
	except Exception as e:
		raise ShimHTTPError(falcon.HTTP_400, 'Error downloading file', logging.WARNING, 'Error downloading: ' + e.__class__.__name__ + ': ' + str(e), add_skip_status=True)
